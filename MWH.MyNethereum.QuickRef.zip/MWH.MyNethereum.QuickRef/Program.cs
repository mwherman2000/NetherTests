﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Nethereum.Hex.HexTypes;
using Nethereum.Web3;
using Nethereum.ABI.FunctionEncoding.Attributes;

namespace MWH.MyNethereum.QuickRef
{
    class Program
    {
        const string senderAddress1 = "0x3866E56fDb1DE93186a93215f1C13Cd1E4C94174";
        const string senderPassword1 = "evlewt12";

        const string receiverAddress1 = "0x7fba3a49aa2acaebaebe722ded44817b4cc60460";

        const string contractAddress1 = "0x059ffc13aa80990430e4d75eaee573642d5bcd20"; // Test3
        const string contractAbi1 = @"[{""constant"":false,""inputs"":[{""name"":""i"",""type"":""uint256""},{""name"":""m"",""type"":""string""}],""name"":""setMsg"",""outputs"":[{""name"":""mi"",""type"":""uint256""}],""payable"":false,""stateMutability"":""nonpayable"",""type"":""function""},{""constant"":false,""inputs"":[{""name"":""value"",""type"":""int256""}],""name"":""multiply"",""outputs"":[{""name"":""product"",""type"":""int256""}],""payable"":false,""stateMutability"":""nonpayable"",""type"":""function""},{""constant"":true,""inputs"":[{""name"":""index"",""type"":""uint256""}],""name"":""getMsg"",""outputs"":[{""name"":""m"",""type"":""string""}],""payable"":false,""stateMutability"":""view"",""type"":""function""},{""constant"":true,""inputs"":[],""name"":""_product"",""outputs"":[{""name"":"""",""type"":""int256""}],""payable"":false,""stateMutability"":""view"",""type"":""function""},{""constant"":true,""inputs"":[],""name"":""getProduct"",""outputs"":[{""name"":""product"",""type"":""int256""}],""payable"":false,""stateMutability"":""view"",""type"":""function""},{""inputs"":[],""payable"":false,""stateMutability"":""nonpayable"",""type"":""constructor""},{""anonymous"":false,""inputs"":[{""indexed"":true,""name"":""sender"",""type"":""address""},{""indexed"":false,""name"":""oldProduct"",""type"":""int256""},{""indexed"":false,""name"":""value"",""type"":""int256""},{""indexed"":false,""name"":""newProduct"",""type"":""int256""}],""name"":""MultipliedEvent"",""type"":""event""},{""anonymous"":false,""inputs"":[{""indexed"":true,""name"":""sender"",""type"":""address""},{""indexed"":true,""name"":""ind"",""type"":""uint256""},{""indexed"":false,""name"":""msg"",""type"":""string""}],""name"":""NewMessageEvent"",""type"":""event""}]";
        
        static void Main(string[] args)
        {
            const int ONE_WEI = 1;

            Web3 web3 = new Web3();

            var task0 = TaskExamples.GetProtocolVersionExample(web3);
            task0.Wait();
            Console.WriteLine("GetProtocolVersionExample: done");

            var task1 = TaskExamples.GetMaxBlockExample(web3);
            task1.Wait();
            Console.WriteLine("GetMaxBlockExample: done");

            var task2 = TaskExamples.GetAccountBalanceExample(web3, senderAddress1);
            task2.Wait();
            Console.WriteLine("GetAccountBalanceExample: done");
            task2 = TaskExamples.GetAccountBalanceExample(web3, receiverAddress1);
            task2.Wait();
            Console.WriteLine("GetAccountBalanceExample: done");

            var task3 = TaskExamples.SendEtherExample(web3, senderAddress1, senderPassword1, receiverAddress1, ONE_WEI);
            task3.Wait();
            Console.WriteLine("SendEtherExample: done");

            var task4 = TaskExamples.WaitForTxReceiptExample(web3, TaskExamples.LastTxHash);
            task4.Wait();
            Console.WriteLine("WaitForTxReceiptExample: done");

            var task5 = TaskExamples.ScanBlocksExample(web3, (ulong)TaskExamples.LastMaxBlockNumber.Value-20000, (ulong)TaskExamples.LastMaxBlockNumber.Value);
            task5.Wait();
            Console.WriteLine("ScanBlocksExample: done");

            var task6 = TaskExamples.ListPersonalAccountsExample(web3);
            task6.Wait();
            Console.WriteLine("ListPersonalAccountsExample: done");

            var task7 = TaskExamples.ScanTxExample(web3, (ulong)TaskExamples.LastMaxBlockNumber.Value - 50, (ulong)TaskExamples.LastMaxBlockNumber.Value);
            task7.Wait();
            Console.WriteLine("ScanTxExample: done");

            var task8 = TaskExamples.InteractWithExistingContract(web3, senderAddress1, senderPassword1, contractAddress1, contractAbi1);
            task8.Wait();
            Console.WriteLine("InteractWithExistingContract: done");

            var task9 = TaskExamples.InteractWithExistingContractWithEvents(web3, senderAddress1, senderPassword1, contractAddress1, contractAbi1);
            task9.Wait();
            Console.WriteLine("InteractWithExistingContractWithEvents: done");

            var task10 = TaskExamples.GetContractValuesHistoryUniqueOffsetValueExample(web3, contractAddress1, TaskExamples.LastMaxBlockNumber, 3);
            task10.Wait();
            Console.WriteLine("GetContractValuesHistoryUniqueOffsetValueExample: done");

            //var task = DoWork(web3);
            //task.Wait();
            //Console.WriteLine("DoWork: done");

            Console.ReadLine();
        }

        static public async Task DoWork(Web3 web3)
        {
            var maxBlockNumber = await web3.Eth.Blocks.GetBlockNumber.SendRequestAsync();
            Console.WriteLine("maxBlockNumber: " + maxBlockNumber.Value.ToString());

            //var contractAddress12 = "0x9EDCb9A9c4d34b5d6A082c86cb4f117A1394F831";
            //                     "0x1B31d19B6a9a942BBf3c197cA1e5EfEde3fF8fF2";

            string oldVal = "";
            for (ulong b = (ulong)maxBlockNumber.Value; b > (ulong)maxBlockNumber.Value - 500; b--)
            {
                var bp = new Nethereum.RPC.Eth.DTOs.BlockParameter(b);
                var stgVal = await web3.Eth.GetStorageAt.SendRequestAsync(contractAddress1, new HexBigInteger(3), bp);
                if (stgVal != oldVal)
                {
                    var blK = await web3.Eth.Blocks.GetBlockWithTransactionsByNumber.SendRequestAsync(bp);
                    DateTime dtBLK = Helpers.UnixTimeStampToDateTime((double)blK.Timestamp.Value);
                    Console.WriteLine("DoWork: dtBLK: " + dtBLK.ToString());

                    for (int i = 0; i <= 5; i++)
                    {
                        var stgValue = await web3.Eth.GetStorageAt.SendRequestAsync(contractAddress1, new HexBigInteger(i), bp);
                        Console.WriteLine("stgValue: " + b.ToString() + " " + i.ToString() + " " + stgValue + " " + Helpers.ConvertHex(stgValue.Substring(2)));
                    }
                    oldVal = stgVal;
                }
            }

            var bl = await web3.Eth.GetBalance.SendRequestAsync(receiverAddress1);
            string sbl = Web3.Convert.FromWei(bl.Value).ToString();
            Console.WriteLine("DoWork: receiverAddress1: " + sbl);

            var unlockResultL = await web3.Personal.UnlockAccount.SendRequestAsync(senderAddress1, senderPassword1, 120);
            var txSend = await web3.Eth.TransactionManager.SendTransactionAsync(senderAddress1, receiverAddress1, new HexBigInteger(1));
            var txReceiptL = await web3.Eth.Transactions.GetTransactionReceipt.SendRequestAsync(txSend);
            int timeoutCountL = 0;
            while (txReceiptL == null && timeoutCountL < 24)
            {
                Console.WriteLine("DoWork: sleeping...");
                Thread.Sleep(5000);
                txReceiptL = await web3.Eth.Transactions.GetTransactionReceipt.SendRequestAsync(txSend);
                timeoutCountL++;
            }
            Console.WriteLine("DoWork: timeoutCount " + timeoutCountL.ToString());

            bl = await web3.Eth.GetBalance.SendRequestAsync(receiverAddress1);
            sbl = Web3.Convert.FromWei(bl.Value).ToString();
            Console.WriteLine("DoWork: receiverAddress1: " + sbl);

            var accts = await web3.Personal.ListAccounts.SendRequestAsync();
            foreach (var a in accts)
            {
                Console.WriteLine("a: " + a);

                var b = await web3.Eth.GetBalance.SendRequestAsync(a);
                string sb = Web3.Convert.FromWei(b.Value).ToString();
                Console.WriteLine("DoWork: balance: " + sb);
            }

            var balance = await web3.Eth.GetBalance.SendRequestAsync(senderAddress1);
            string sBalance = Web3.Convert.FromWei(balance.Value).ToString();
            Console.WriteLine("DoWork: balance: " + sBalance);

            var blockNumber = await web3.Eth.Blocks.GetBlockNumber.SendRequestAsync();
            Console.WriteLine("DoWork: blockNumber: " + blockNumber.Value.ToString());

            long txcnt = 0;
            for (ulong b = (ulong)0; b <= (ulong)maxBlockNumber.Value; b++)
            {
                var bp = new Nethereum.RPC.Eth.DTOs.BlockParameter(b);
                var block = await web3.Eth.Blocks.GetBlockWithTransactionsByNumber.SendRequestAsync(bp);
                var trans = block.Transactions;
                int cnt = trans.Length;
                //if (cnt != 0) System.Diagnostics.Debugger.Break();
                txcnt += cnt;
                if (b % 1000 == 0) Console.Write(".");
                if (b % 10000 == 0)
                {
                    Console.Write(b.ToString());
                    DateTime dt = Helpers.UnixTimeStampToDateTime((double)block.Timestamp.Value);
                    Console.WriteLine(" " + txcnt.ToString() + " " + dt.ToString());
                }
            }
            Console.WriteLine();

            for (ulong b = (ulong)maxBlockNumber.Value; b > (ulong)maxBlockNumber.Value - 5000; b--)
            {
                var bp = new Nethereum.RPC.Eth.DTOs.BlockParameter(b);
                var block = await web3.Eth.Blocks.GetBlockWithTransactionsByNumber.SendRequestAsync(bp);
                DateTime dt = Helpers.UnixTimeStampToDateTime((double)block.Timestamp.Value);
                Console.WriteLine("Block: " + b.ToString() + " " + dt.ToString());
                var trans = block.Transactions;
                foreach (var t in trans)
                {
                    try
                    {
                        var bn = t.BlockNumber.Value;
                        var th = t.TransactionHash;
                        var ti = t.TransactionIndex.Value;

                        var rpt = await web3.Eth.Transactions.GetTransactionReceipt.SendRequestAsync(th);
                        var status = rpt.Status.Value;

                        var nc = t.Nonce.Value;
                        var from = t.From;

                        Console.WriteLine(th.ToString() + " " + ti.ToString() + " " + nc.ToString() + " " + from.ToString() + " " + status.ToString());

                        var to = t.To;
                        if (to == null) to = "to:NULL";
                        var v = t.Value.Value;
                        var g = t.Gas.Value;
                        var gp = t.GasPrice.Value;
                        Console.WriteLine(th.ToString() + " " + ti.ToString() + " " + nc.ToString() + " " + from.ToString() + " " + to.ToString() + " " + v.ToString() + " " + g.ToString() + " " + gp.ToString());
                    }
                    catch(Exception e)
                    {
                        Console.WriteLine("block.Transaction: " + e.ToString());
                        if (e.InnerException != null) Console.WriteLine("block.Transaction: " + e.InnerException.ToString());
                    }
                 }
            }

            var contract = web3.Eth.GetContract(contractAbi1, contractAddress1);

            var setMsg = contract.GetFunction("setMsg");
            var getMsg = contract.GetFunction("getMsg");
            var multipliedEvent = contract.GetEvent("MultipliedEvent");
            var newMsgEvent = contract.GetEvent("NewMessageEvent");

            var filterAllMultiplied = await multipliedEvent.CreateFilterAsync();
            var filterAllNewMsgs = await newMsgEvent.CreateFilterAsync();

            string now = DateTime.UtcNow.ToString() + " UTC";
            Console.WriteLine("DoWork: now: " + now);
            //object[] parms = { 2, now };
            //var setResult = await setMsg.CallAsync<int>(parms);

            var unlockResult = await web3.Personal.UnlockAccount.SendRequestAsync(senderAddress1, senderPassword1, 120);
            var txHash1 = await setMsg.SendTransactionAsync(senderAddress1, new HexBigInteger(900000), null, 1, "Hello World");
            Console.WriteLine("DoWork: txHash1: " + txHash1.ToString());
            var txHash2 = await setMsg.SendTransactionAsync(senderAddress1, new HexBigInteger(900000), null, 2, now);
            Console.WriteLine("DoWork: txHash2: " + txHash2.ToString());

            var txReceipt = await web3.Eth.Transactions.GetTransactionReceipt.SendRequestAsync(txHash1);
            int timeoutCount = 0;
            while (txReceipt == null && timeoutCount < 24)
            {
                Console.WriteLine("DoWork: sleeping...");
                Thread.Sleep(5000);
                txReceipt = await web3.Eth.Transactions.GetTransactionReceipt.SendRequestAsync(txHash1);
                timeoutCount++;
            }
            Console.WriteLine("DoWork: timeoutCount " + timeoutCount.ToString());

            var txReceipt3 = await setMsg.SendTransactionAndWaitForReceiptAsync(senderAddress1, new HexBigInteger(900000), null, null, 2, now + " Wait");
            Console.WriteLine("DoWork: txReceipt3: " + txReceipt3.TransactionHash.ToString());
            Console.WriteLine("DoWork: txReceipt3: " + txReceipt3.CumulativeGasUsed.Value.ToString());


            var getResult1 = await getMsg.CallAsync<string>(1);
            Console.WriteLine("DoWork: done: " + getResult1.ToString());
            var getResult2 = await getMsg.CallAsync<string>(2);
            Console.WriteLine("DoWork: done: " + getResult2.ToString());

            var logMultiplied = await multipliedEvent.GetFilterChanges<FunctionOutputHelpers.MultipliedEventArgs>(filterAllMultiplied);
            foreach (var mea in logMultiplied)
            {
                Console.WriteLine("logMultiplied: " +
                mea.Event.sender + " " + mea.Event.oldProduct.ToString() + " " + mea.Event.value.ToString() + " " + mea.Event.newProduct.ToString());
            }

            var logNewMessage = await newMsgEvent.GetFilterChanges<FunctionOutputHelpers.NewMessageEventArgs>(filterAllNewMsgs);
            foreach (var mea in logNewMessage)
            {
                Console.WriteLine("logNewMessage: " +
                mea.Event.sender + " " + mea.Event.ind.ToString() + " " + mea.Event.msg.ToString());
            }
        }
    }
}
